run `make` to compile all files
executables create run with p5testscript
comments are not as extensive as I usually do, but they are there and explain enough
